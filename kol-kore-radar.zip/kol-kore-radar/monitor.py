# -*- coding: utf-8 -*-
"""
רדאר קולות קוראים — משרד החינוך ורשות החדשנות
==================================================
סורק פעם ביום את עמודי הקולות הקוראים, מזהה פרסומים חדשים
ושולח התראה במייל (Gmail) רק כשיש משהו חדש.

מבנה:
  SOURCES        — רשימת העמודים שנסרקים + פונקציית חילוץ לכל עמוד
  KEYWORDS       — מילות מפתח להדגשה (לא מסננות — רק מסמנות 🔥)
  state.json     — המצב השמור (נכתב חזרה לריפו ע"י ה-workflow)

סודות נדרשים ב-GitHub (Settings → Secrets → Actions):
  GMAIL_USER          — כתובת ה-Gmail השולחת
  GMAIL_APP_PASSWORD  — App Password (לא הסיסמה הרגילה!)
  MAIL_TO             — כתובת היעד (אפשר כמה, מופרדות בפסיק)
"""

import json
import os
import re
import smtplib
import ssl
import sys
from datetime import datetime, timezone, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

STATE_FILE = "state.json"
TIMEOUT = 30
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    "Accept-Language": "he-IL,he;q=0.9,en;q=0.8",
}

# מילות מפתח שמסומנות 🔥 בהתראה (אפשר להוסיף/להסיר בחופשיות)
KEYWORDS = [
    "אנגלית", "בינה מלאכותית", "AI", "720", "למידה מותאמת",
    "שפה דבורה", "דבורה", "חטיבות ביניים", "STEM",
]


# ---------------------------------------------------------------------------
# פונקציות חילוץ — אחת לכל מקור. כל פונקציה מחזירה רשימת (title, url)
# ---------------------------------------------------------------------------

def extract_edu_tech(html: str, base_url: str):
    """מינהל חדשנות וטכנולוגיה — עמוד הקולות הקוראים."""
    soup = BeautifulSoup(html, "html.parser")
    items = []
    for a in soup.select("a[href*='/taknot/kol-kore/']"):
        href = a.get("href", "")
        title = a.get_text(strip=True)
        # מסננים את עמוד האינדקס עצמו וקישורים ריקים
        if not title or href.rstrip("/").endswith("/taknot/kol-kore"):
            continue
        items.append((title, urljoin(base_url, href)))
    return items


def extract_innovation_authority(html: str, base_url: str):
    """רשות החדשנות — עמוד הקולות הקוראים (kol_kore)."""
    soup = BeautifulSoup(html, "html.parser")
    items = []
    for a in soup.select("a[href*='/kol_kore/']"):
        href = a.get("href", "")
        title = a.get_text(strip=True)
        if not title or href.rstrip("/").endswith("/kol_kore"):
            continue
        # רק קולות קוראים בתחומי חינוך/AI — סינון רך לפי כותרת
        items.append((title, urljoin(base_url, href)))
    return items


def extract_generic(html: str, base_url: str):
    """חילוץ גנרי — כל קישור שמכיל 'קול קורא' בטקסט שלו."""
    soup = BeautifulSoup(html, "html.parser")
    items = []
    for a in soup.find_all("a"):
        title = a.get_text(strip=True)
        href = a.get("href", "")
        if href and "קול קורא" in title:
            items.append((title, urljoin(base_url, href)))
    return items


SOURCES = [
    {
        "id": "edu-tech",
        "name": "מינהל חדשנות וטכנולוגיה (משרד החינוך)",
        "url": "https://edu-tech.education.gov.il/taknot/kol-kore/",
        "extractor": extract_edu_tech,
    },
    {
        "id": "innovation-authority",
        "name": "רשות החדשנות",
        "url": "https://innovationisrael.org.il/kol_kore/",
        "extractor": extract_innovation_authority,
    },
    {
        "id": "pob-education",
        "name": "פורטל רשויות ובעלויות חינוך",
        "url": "https://pob.education.gov.il/kolotkorim/kolkore/",
        "extractor": extract_generic,
    },
]


# ---------------------------------------------------------------------------
# מצב שמור
# ---------------------------------------------------------------------------

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def normalize(url: str) -> str:
    """מפתח יציב להשוואה — בלי פרמטרים, בלי סלאש סופי."""
    return re.sub(r"[?#].*$", "", url).rstrip("/").lower()


# ---------------------------------------------------------------------------
# מייל
# ---------------------------------------------------------------------------

def has_keyword(title: str) -> bool:
    t = title.lower()
    return any(k.lower() in t for k in KEYWORDS)


def build_email_html(new_by_source: dict) -> str:
    il_now = datetime.now(timezone(timedelta(hours=3))).strftime("%d/%m/%Y %H:%M")
    rows = []
    for source_name, items in new_by_source.items():
        rows.append(
            f'<h3 style="margin:18px 0 6px;color:#1a3c6e;">{source_name}</h3>'
        )
        for title, url in items:
            flame = "🔥 " if has_keyword(title) else ""
            rows.append(
                f'<div style="margin:6px 0;padding:10px 14px;background:#f5f8fc;'
                f'border-radius:8px;border-inline-start:4px solid #1a73e8;">'
                f'{flame}<a href="{url}" style="color:#1a3c6e;font-weight:600;'
                f'text-decoration:none;">{title}</a></div>'
            )
    total = sum(len(v) for v in new_by_source.values())
    return f"""\
<html dir="rtl" lang="he"><body style="font-family:Arial,Helvetica,sans-serif;
direction:rtl;text-align:right;color:#222;max-width:640px;margin:0 auto;">
<h2 style="color:#1a3c6e;">📣 רדאר קולות קוראים — {total} פרסומים חדשים</h2>
<p style="color:#666;font-size:13px;">נבדק ב-{il_now} (שעון ישראל)</p>
{''.join(rows)}
<p style="color:#999;font-size:12px;margin-top:24px;">
🔥 = מכיל מילת מפתח רלוונטית (אנגלית / AI / 720 / למידה מותאמת ועוד).<br>
הודעה אוטומטית מרדאר הקולות הקוראים.</p>
</body></html>"""


def send_email(new_by_source: dict):
    user = os.environ["GMAIL_USER"]
    app_password = os.environ["GMAIL_APP_PASSWORD"]
    recipients = [r.strip() for r in os.environ["MAIL_TO"].split(",") if r.strip()]

    total = sum(len(v) for v in new_by_source.values())
    hot = any(
        has_keyword(t) for items in new_by_source.values() for t, _ in items
    )
    subject = ("🔥 " if hot else "") + f"קול קורא חדש! ({total}) — רדאר קולות קוראים"

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(build_email_html(new_by_source), "html", "utf-8"))

    ctx = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ctx) as server:
        server.login(user, app_password)
        server.sendmail(user, recipients, msg.as_string())
    print(f"נשלח מייל עם {total} פרסומים חדשים אל {recipients}")


# ---------------------------------------------------------------------------
# ריצה ראשית
# ---------------------------------------------------------------------------

def main():
    state = load_state()
    first_run = not state
    new_by_source = {}
    errors = []

    for src in SOURCES:
        try:
            resp = requests.get(src["url"], headers=HEADERS, timeout=TIMEOUT)
            resp.raise_for_status()
            items = src["extractor"](resp.text, src["url"])
        except Exception as e:  # noqa: BLE001
            errors.append(f"{src['name']}: {e}")
            print(f"⚠️ שגיאה במקור {src['id']}: {e}", file=sys.stderr)
            continue

        # דה-דופליקציה בתוך המקור
        seen_now, unique_items = set(), []
        for title, url in items:
            key = normalize(url)
            if key not in seen_now:
                seen_now.add(key)
                unique_items.append((title, url, key))

        known = set(state.get(src["id"], []))
        fresh = [(t, u) for t, u, k in unique_items if k not in known]

        # מעדכנים את המצב — שומרים גם ישנים כדי לא להתריע שוב אם קישור נעלם וחוזר
        state[src["id"]] = sorted(known | {k for _, _, k in unique_items})

        if fresh and not first_run:
            new_by_source[src["name"]] = fresh
        print(f"{src['id']}: נמצאו {len(unique_items)} פריטים, מהם {len(fresh)} חדשים")

    save_state(state)

    if first_run:
        print("ריצה ראשונה — נשמר מצב בסיס, לא נשלחת התראה.")
        return

    if new_by_source:
        send_email(new_by_source)
    else:
        print("אין פרסומים חדשים.")

    # אם כל המקורות נכשלו — נכשיל את הריצה כדי שתקבל התראת כשל מגיטהאב
    if errors and len(errors) == len(SOURCES):
        sys.exit(1)


if __name__ == "__main__":
    main()
